
    function callbackFn(details) {
        var remove_headers = [];
        var add_or_modify_headers = {'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjkxNDEyODQwYzEwMTlkZWRmZjE4NTRiODk5MzhhZDBhOTA3OGI4NzEifQ.eyJhdWQiOiIzMjg4NTIyNTkzMzktY2NyYXE5MG5uZmtydXZpZGQwYmgxcmIyOXNoZThydXAuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhenAiOiJ0ZXN0LXNlcnZpY2UtYWNjb3VudEBhbHdheXMtbmV3LXNlY3VyaXR5LXN0cmF3bWFuLmlhbS5nc2VydmljZWFjY291bnQuY29tIiwic3ViIjoiMTA4NDExMDc4NTAxNjgxMDA3NzIzIiwiZW1haWwiOiJ0ZXN0LXNlcnZpY2UtYWNjb3VudEBhbHdheXMtbmV3LXNlY3VyaXR5LXN0cmF3bWFuLmlhbS5nc2VydmljZWFjY291bnQuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImlzcyI6Imh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbSIsImlhdCI6MTUwMjgyMTE5OSwiZXhwIjoxNTAyODI0Nzk5fQ.aYupNchniPyD_uwPlrtqp4NEHHgnpvSlxWGhNIaTryyvhgj9kNSAYStvi5zEBritM5jedcSbB7weJrsxzdRMlu5NsROQgsk_eRiR76YIyT-8Okt66Hwa5SGeqNepDQd0Te3ilh6alGhQwkRvW-erfdsp33hS64mqv8Nljz7Fj_6rMNu95CFjBhvSm6VGOZ6esL2FfbNVNEEKZn2ZMOjVr9a2Fd3lEM_VVzfAr20JJ_kh-X9L1iprdOg9Lg6QYSbBBToy_-7bbwNjSDO-zVuTxFOvMeVAvUCjMakTQaYCMDzz3-yq5ZknO_rUXEF2FEXNsF7LjHS80gnK6MToIJn9aQ'};

        function inarray(arr, obj) {
            return (arr.indexOf(obj) != -1);
        }

        // remove headers
        for (var i = 0; i < details.requestHeaders.length; ++i) {
            if (inarray(remove_headers, details.requestHeaders[i].name)) {
                details.requestHeaders.splice(i, 1);
                var index = remove_headers.indexOf(5);
                remove_headers.splice(index, 1);
            }
            if (!remove_headers.length) break;
        }

        // modify headers
        for (var i = 0; i < details.requestHeaders.length; ++i) {
            if (add_or_modify_headers.hasOwnProperty(details.requestHeaders[i].name)) {
                details.requestHeaders[i].value = add_or_modify_headers[details.requestHeaders[i].name];
                delete add_or_modify_headers[details.requestHeaders[i].name];
            }
        }

        // add modify
        for (var prop in add_or_modify_headers) {
            details.requestHeaders.push(
                {name: prop, value: add_or_modify_headers[prop]}
            );
        }

        return {requestHeaders: details.requestHeaders};
    }

    chrome.webRequest.onBeforeSendHeaders.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking', 'requestHeaders']
    );
    